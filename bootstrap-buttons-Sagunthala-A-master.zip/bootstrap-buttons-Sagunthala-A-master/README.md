# Bootstrap Buttons

Rendering simple buttons without color is not always the best user interface. To get the best user experience bootstrap buttons are used instead of simple buttons each and every time. Designing a button with proper animation and color from scratch is a bit hard. That's where Bootstrap 'Buttons' makes frontend developer's life easier.
 
 In this assignment, we are going to create Bootstrap Buttons.
 <li>There are 8 buttons with respective ids #button-1, #button-2, #button-3, #button-4, #button-5, #button-6, #button-7, #button-8</li> <li>add the classes in buttons to meet the requirements which is given in image </li>
 <br>
 
 <img src="https://d3dyfaf3iutrxo.cloudfront.net/thumbnail/assignment/question/2c53c2c7e03f48a7903dc7591fffe196.png">
 
 
 <strong>Refer Bootstrap Buttons <a href = "https://getbootstrap.com/docs/4.0/components/buttons/">documentation</a></strong>
 <strong>Refer Testcases for better idea</strong>

